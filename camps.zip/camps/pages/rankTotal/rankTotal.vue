<template>
	<view class="rankTotal_mainbox">
		<view class="switchRanks">
			<view :class="[per=='day'?'Main_rank_ranks_act':'Main_rank_ranks']" @click="per = 'day'">每天</view>
			<view :class="[per=='week'?'Main_rank_ranks_act':'Main_rank_ranks']" @click="per = 'week'">每周</view>
			<view :class="[per=='month'?'Main_rank_ranks_act':'Main_rank_ranks']" @click="per = 'month'">每月</view>
		</view>
		<view class="rankTotal_top">
			<view class="rankTop_photo">
				<image :src="top.photo" mode=""></image>
			</view>
			<view>
				<template v-if="mine.name==top.name">
					<text >你目前<text class="rank_topName">{{top.name}}</text>暂居第一</text><br>
					<text>请继续保持</text>
				</template>
				<template v-else>
					<text >你的好友<text class="rank_topName">{{top.name}}</text>暂居第一</text><br>
					<text>请再接再厉</text>
				</template>
			</view>
		</view>
	</view>
	<view class="rankTotal_rankList">
		<unicloud-db v-slot:default="{data, loading, error, options}" collection="ranksTotal">
			<view v-if="error">{{error.message}}</view>
			<view v-else>
			<template v-for="item in data" :key="_id">
				<template v-if="item.per == per">
					<view class="Main_rank_item" v-for="lists in item.list" :key="index" >
						<view>{{lists.rank}}</view>&nbsp;&nbsp;&nbsp;&nbsp;
						<text>{{lists.name}}</text>
						<text>{{lists.mileage}}km</text>
						<text class="{{lists.fav>0?'hasFav':'noFav'}}">❤{{lists.fav}}</text>
					</view>
				</template>
			</template>>
			</view>
		</unicloud-db>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userName:'other4',
				per:'day',
				rankTotal:{},
				show:[],
				mine:{},
				top:{}
			};
		},
		methods:{
			getRanks(){
				let _this = this
				const db = uniCloud.database() //代码块为cdb
				// 使用uni-clientDB
				db.collection('ranksTotal').get()
				  .then((res)=>{
				    // res 为数据库查询结果
					this.rankTotal = res.result.data
					console.log(_this.rankTotal)
					this.initShow()
				  }).catch((err)=>{
				    console.log(err.code); // 打印错误码
						console.log(err.message); // 打印错误内容
				  })
			},
			initShow(){
				let temp = {}
				for(let i in this.rankTotal){
					if(this.rankTotal[i].per == this.per)
					temp = this.rankTotal[i]
					this.show = temp.list
					this.mine = this.show.filter(item=>item.name=="other3")[0]
					this.top = this.show.filter(item=>item.rank==1)[0]
				}
				console.log(temp)
				console.log('##',this.show)
				console.log('###',this.mine)
				console.log('####',this.top)
			}
		},
		watch: {
			 // per: {
			 //        handler(newName, oldName) {
				// 		this.initShow()
			 //   //          console.log('>>',newName)
				// 		// this.show = this.rankTotal.filter(item=>item.per==newName)
				// 		// console.log('>>>',this.show)
			 //        },
			 //        // immediate: true,
			 //        deep: true
			 //    }

		},
		onShow(){
			this.getRanks()
		}
	}
</script>

<style lang="less" scoped>
.rankTotal_mainbox{
	width: 750rpx;
	height: 470rpx;
	padding-top: 50rpx;
	background-color: aqua;
	background-image: url(https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Camps/rankTotal/LBD$HMZRV3T_TT`}O3XPJ{0.png);
	background-size: cover;
	background-repeat: no-repeat;
	position: relative;
}
// 选择器
.switchRanks{
		width: 700rpx;
		height: 50rpx;
		margin: auto;
		border-radius: 25rpx;
		display: flex;
		justify-content: space-around;
		background: black;
	}
	.Main_rank_ranks{
		width: 200rpx;
		height: 50rpx;
		border-radius: 25rpx;
		color: white;
		text-align: center;
	}
	.Main_rank_ranks_act{
		width: 200rpx;
		height: 50rpx;
		border-radius: 25rpx;
		background: #F9DE00;
		text-align: center;
		// transition: all 0.2s linear;
	}
	.rankTotal_top{
		width: 500rpx;
		height: 100rpx;
		margin:300rpx auto;
		// border: 3px solid  #F9DE00;
		background: rgba(255, 255, 255, 0.5);
		display: flex;
		justify-content: center;
		align-items: left;
		line-height: 50rpx;
		.rankTop_photo{
			width: 100rpx;
			height: 100rpx;
			border: 2px gold solid;
			background: pink;
			border-radius: 50rpx;
			margin-right: 20rpx;
			overflow: hidden;
			image{
				width: 100rpx;
				height: 100rpx;
			}
		}
		.rank_topName{
			font-weight: 700;
			
		}
	}
	
	// 以下是列表样式
	.rankTotal_rankList{
		width: 750rpx;
		padding: 20rpx 0 20rpx 0;
		background: #333333;
	}
	
	.Main_rank_item{
		width: 700rpx;
		height: 100rpx;
		margin: 20rpx auto;
		line-height: 100rpx;
		text-align: center;
		font-weight: 700;
		background: white;
		border-radius: 50rpx;
		display: flex;
		align-items: center;
		justify-content: left;
		overflow: hidden;
		view{
			display: block;
			width: 98rpx;
			height: 98rpx;
			border-radius: 48rpx;
			
		}
		text{
			display: block;
			width: 150rpx;
			margin-left: 50rpx;
		}
		.hasFav{
			color: red;
		}
		.noFav{
			color: black;
		}
	}
	.Main_rank_item:nth-child(1){
		border: 3px red solid;
		view{
			border-right: 3px crimson solid;
		}
	}
	.Main_rank_item:nth-child(2){
		border: 3px #F9DE00 solid;
		view{
			border-right: 3px #F9DE00 solid;
		}
	}
	.Main_rank_item:nth-child(3){
		border: 3px black solid;
		view{
			border-right: 3px black solid;
		}
	}
</style>
