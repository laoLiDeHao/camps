<template>
	<view class="adventure_detail">
		<view class="adv_de_top">
			<view class="adv_top_title">{{showThis.title}}</view>
			<view class="adv_top_photo">
				<uni-swiper-dot  :info="showThis.photo" :current="current" :mode="mode" id="swiper_1"  :dots-styles="dotsStyles">
					<swiper class="swiper-box" @change="change">
						<swiper-item v-for="(item ,index) in showThis.photo" :key="index">
							<view class="swiper-item">
								<image :src="item"  mode=""></image>
							</view>
						</swiper-item>
					</swiper>
				</uni-swiper-dot>
			</view>
		</view>
		<view class="adv_de_bottom">
			<view ><text class="grayWords">发起 人 :</text>{{showThis.member[0]}}</view>
			<view ><text class="grayWords">活动日期:</text>{{showThis.time}}</view>
			<view ><text class="grayWords">活动地址:</text>{{showThis.position}}</view>
			<view ><text class="grayWords">计划人数:</text>{{showThis.amount}}</view>
			<view  ><text class="grayWords">现有成员:</text></view>
			<view class="memberTag"><view v-for='members in showThis.member'>{{members}}&nbsp;</view></view>
			<button type="reset" @click="off">确定</button>
		</view>
	</view>
</template>

<script>
	export default {
		name:"advDetail",
		props:["showThis"],
		data() {
				return {
					info: [{
						content: '内容 A'
					}, {
						content: '内容 B'
					}, {
						content: '内容 C'
					}],
					current: 0,
					mode: 'round',
					swiperDotIndex: 0,
					modeIndex: -1,
					styleIndex: -1,
					dotsStyles:{
						width:20,
						bottom:20,
						backgroundColor: 'rgba(255, 90, 95,0.3)',
						border: '1px rgba(255, 90, 95,0.3) solid',
						color: '#fff',
						selectedBackgroundColor: 'rgba(255, 90, 95,0.9)',
						selectedBorder: '1px rgba(255, 90, 95,0.9) solid'
					}
				}
		},
		methods: {
			change(e) {
				this.current = e.detail.current;
			},
			clickItem(e) {
				this.swiperDotIndex = e
			},
			onBanner(index) {
				console.log(22222, index);
			},
			off(){
				this.$emit('off')
			}
			
		},
		
	}	
</script>

<style lang="less" scoped>
	.adventure_detail{
		width: 700rpx;
		height: 1000rpx;
		overflow: auto;
		padding: 40rpx 25rpx 10rpx 25rpx;
		background: #333333;
	}
	.adv_de_top{
		width: 700rpx;
		height: 800rpx;
		background: #999999;
		border-radius: 20rpx;
		margin-bottom: 20rpx;
		overflow: hidden;
	}
	.adv_top_title{
		width: 700rpx;
		height: 80rpx;
		line-height: 80rpx;
		font-size: 35rpx;
		color: white;
		font-weight: 500;
		text-align: center;
		border-bottom: 1px black dashed;
		position: relative;
		&:before{
			content: '  ';
			display: block;
			width: 50rpx;
			height: 50rpx;
			border-radius: 25rpx;
			background: #333333;
			position: absolute;
			bottom: -25rpx;
			left: -25rpx;
		}
		&::after{
			content: '  ';
			display: block;
			width: 50rpx;
			height: 50rpx;
			border-radius: 25rpx;
			background: #333333;
			position: absolute;
			bottom: -25rpx;
			right: -25rpx;
		}
		// background: aqua;
	}
	.adv_top_photo{
		width: 700rpx;
		height: 720rpx;
		background: #999999;
		display: flex;
		justify-content: center;
		align-items: center;
		uni-swiper-dot{
			width: 600rpx;
			height: 600rpx;
			// border: 1px solid red;
			swiper{
				width: 600rpx;
				height: 600rpx;
				image{
					width: 600rpx;
					height: 600rpx;
				}
				
			}
		}
	}
	
	
	.adv_de_bottom{
		width: 660rpx;
		// height: 400rpx;
		padding: 20rpx 20rpx 20rpx 20rpx;
		background: #999999;
		border-radius: 20rpx;
		margin-bottom: 20rpx;
		color: white;
		view{
			width: 660rpx;
			margin-bottom: 20rpx;
		}
	}
	.memberTag{
		width: 660rpx;
		// background: red;
		padding : 10rpx 0 10rpx 0;
		display: flex;
		flex-wrap: wrap;
		/deep/view{
			width: auto;
			margin: 5rpx 5rpx 5rpx 5rpx;
		}
	}
	
	.grayWords{
		color: dimgray;
	}
	
</style>