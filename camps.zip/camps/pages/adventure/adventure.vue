<template>
	<view class="adventure_main">
		<view class="switchTags">
			<view :class="[now=='all'?'tags tag_act':'tags']" @click="now = 'all'">全部活动</view>
			<view :class="[now=='inner'?'tags tag_act':'tags']" @click="now = 'inner'">室内活动</view>
			<view :class="[now=='out'?'tags tag_act':'tags']" @click="now = 'out'">室外活动</view>
			<view :class="[now=='match'?'tags tag_act':'tags']" @click="now = 'match'">竞赛活动</view>
		</view>
		<unicloud-db v-slot:default="{data, loading, error, options}" collection="adventure">
		<view class="ads">
				<view class="ad" v-for="item in data">
					<view  @click="showDetail(item)">
						<image :src="item.cover" mode=""></image>
					</view>
					<view>
						<view class="title">{{item.title}}</view>
						<view class="intro"><text class="grayS">活动日期：</text>{{item.time}}</view>
						<view class="intro"><text class="grayS">计划人数：</text>{{item.amount}}</view>
						<view >已有{{item.member.length}}人参加</view>
						<view class="joinIn" v-if="item.statu===0" @click="alertJoin(item)">立即参加</view>
						<view class="full" v-else-if="item.statu===1" @click="alertFull(item)">已满员</view>
						<view class="over" v-else>已结束</view>
					</view>
					<view class="ad_success" v-if="item.statu===2">
						<image src="/static/已完成.png" mode=""></image>
					</view>
				</view>
		</view>
		</unicloud-db>
	</view>
	<view id="dialog" v-if="isshow">
		<advDetail :showThis="show" @off='off' ></advDetail>
	</view>
<!--  -->
</template>

<script>
	import advDetail from './advDetail.vue'
	export default {
		components:{advDetail},
		data() {
			return {
				now:"all",
				isshow:false,
				show:{}
			}
		},
		methods: {
				alertJoin(item){
					// 报名
					// let db = uniCloud.database()
					// 	// 报名活动
					// 	db.collection('adventure').add().then((res)=>{
					// 		if(成功){
					// 			db.collection('user')
					// 		}else{
					// 			// 提示失败及原因
					// 		}
					// 	})
					
					// 测试默认成功
					uni.showToast({
						title: '已报名成功',
						duration: 2000
					});
				},
				// 提示无法参见
				alertFull(item){
					uni.showToast({
						title: '人数已达上限',
						icon:"error",
						duration: 2000
					});
				},
				showDetail(item){
					this.show = item
					console.log("f",this.show)
					this.isshow = true
				},
				off(){
					this.isshow = false
				}
		}
	}
</script>

<style scoped lang="less">
	.adventure_main{
		width: 750rpx;
		padding: 20rpx 0 50rpx 0 ;
		background:#333333 ;
	}
	.switchTags{
		width: 720rpx;
		height: 50rpx;
		margin: auto;
		// border: 1px crimson solid;
		background: black;
		border-radius: 25rpx;
		display: flex;
		.tags{
			width: 180rpx;
			height: 50rpx;
			line-height: 50rpx;
			border-radius: 25rpx;
			text-align: center;
			color: white;
		}
		.tag_act{
			background:#F9DE00 ;
			color: black;
		}
	}
	
	.ads{
		width: 750rpx;
		height:1400rpx;
		overflow: auto;
		margin-top: 40rpx;
		padding: 10rpx 0 10rpx 0;
		// background: greenyellow;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-around;
		.ad{
			width: 300rpx;
			height: 550rpx;
			background: #999999;
			margin-bottom: 100rpx;
			border-radius: 30rpx;
			position: relative;
			.ad_success{
				width: 45rpx;
				height: 45rpx;
				position: absolute;
				top: 450rpx;
				left: 220rpx;
				
				image{
					width: 45rpx;
					height: 45rpx;
				}
				
			}
			
			
			
			&>view:nth-child(1){
				width: 300rpx;
				height: 300rpx;
				overflow: hidden;
				background: aquamarine;
				border-radius:30rpx  30rpx 0 0; 
				
				image{
					width: 300rpx;
					height: 300rpx;
				}
			}
			&>view:nth-child(2){
				width: 274rpx;
				height: 250rpx;
				padding: 20rpx 10rpx 0 10rpx;
				color: white;
				background: #999999;
				border-radius: 0 0 30rpx  30rpx; 
				border: 2px #F9DE00 solid;
				border-top:none ;
			}
		}
	}
	
	.title{
		font-size: 25rpx;
		font-weight: 700;
	}
	.intro{
		font-size: 25rpx;
	}
	.grayS{
		color: dimgray;
	}
	
	
	.joinIn{
		width: 200rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		margin: auto;
		background: #F9DE00;
		color: black;
		border-radius: 30rpx;
		position: relative;
		top: 80rpx;
	}
	.full,.over{
		width: 200rpx;
		height: 60rpx;
		line-height: 60rpx;
		text-align: center;
		margin: auto;
		border: #F9DE00 1px solid;
		background: #999999;
		color: black;
		border-radius: 30rpx;
		position: relative;
		top: 80rpx;
	}
	
	#dialog{
		position: fixed;
		bottom: 0;
	}
</style>
