<template>
	<view class="friend_main">
		<view class="topLab">
			<view>
				<view>
					<image src="../../static/menu.png" mode=""></image>
				</view>
				<view>选项</view>
			</view>
			<view>
				<input type="text" name="" id="searchs" placeholder="请输入...">
			</view>
			<view>
				<image src="../../static/search.png" mode=""></image>
			</view>
		</view>
		<view class="splits">运动中...</view>
		<template>
			<view class="friend_Tag" v-for="k in 6" :key="index">
				<view class="fir_photo">
					<image src="../../static/fakePhoto.png" mode=""></image>
				</view>
				<view class="fir_text_act">
					<view>ZhangHna g</view>
					<view>正在xxx...</view>
				</view>
				<view class="fir_btn">
					
				</view>
			</view>
		</template>
		<view class="splits">在线</view>
		<template>
			<view class="friend_Tag" v-for="j in 2" :key="index">
				<view class="fir_photo">
					<image src="../../static/fakePhoto.png" mode=""></image>
				</view>
				<view class="fir_text_on">
					<view>ZhangHna g</view>
					<view>正在xxx...</view>
				</view>
				<view class="fir_btn">
					
				</view>
			</view>
		</template>
		<view class="splits">离线</view>
		<template>
			<view class="friend_Tag" v-for="i in 6" :key="index">
				<view class="fir_photo">
					<image src="../../static/fakePhoto.png" mode=""></image>
				</view>
				<view class="fir_text_miss">
					<view>ZhangHna g</view>
					<view>正在xxx...</view>
				</view>
				<view class="fir_btn">
					
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="less">
	.friend_main{
		width: 750rpx;
		min-height: 1440rpx;
		background: #333333;
	}
	
	.topLab{
		width: 750rpx;
		height: 80rpx;
		background: black;
		color: white;
		font-weight: 500;
		display: flex;
		// 搜索框左
		&>view:nth-child(1){
			width: 150rpx;
			height: 80rpx;
			// background: aquamarine;
			display: flex;
			justify-content: center;
			align-items: center;
			font-weight: 700;
			&>view:nth-child(1){
				image{
					width: 75rpx;
					height: 75rpx;
				}
			}
		}
		// 搜索框中
		#searchs{
			width: 450rpx;
			height: 60rpx;
			padding-left: 10rpx;
			font-weight: 700;
			background: #383838;
			margin-top: 10rpx;
		}
		// 搜索框右
		&>view:nth-child(3){
			width: 150rpx;
			height: 80rpx;
			// background: aquamarine;
			display: flex;
			justify-content: center;
			align-items: center;
			image{
				width: 70rpx;
				height: 70rpx;
			}
		}
	}
	
	.splits{
		width: 740rpx;
		height: 40rpx;
		padding-left: 10rpx;
		background: #FFCA28;
		color: black;
		font-size: 30rpx;
		margin: 5rpx 0  10rpx 0;
	}
	.friend_Tag{
		width: 740rpx;
		height: 80rpx;
		padding: 10rpx 10rpx 10rpx 10rpx;
		// background: rgba(249, 222, 0, 0.05);
		background: #000000;
		border-top:1px solid #424242;
		display: flex;
		.fir_photo{
			width: 80rpx;
			height: 80rpx;
			padding-right: 10rpx;
			// border-right: 1px #F9DE00 solid;
			image{
				width: 80rpx;
				height: 80rpx;
			}
		}
		.fir_text_act{
			width: 500rpx;
			height: 80rpx;
			padding-left: 20rpx;
			// border-right: 1px solid #F9DE00;
			color: green;
			&>view:nth-child(1){
				font-size: 35rpx;
			}
			&>view:nth-child(2){
				font-size: 25rpx;
			}
		}
		.fir_text_on{
			width: 500rpx;
			height: 80rpx;
			padding-left: 20rpx;
			// border-right: 1px solid #ffffff;
			color: #F9DE00;
			&>view:nth-child(1){
				font-size: 35rpx;
			}
			&>view:nth-child(2){
				font-size: 25rpx;
			}
		}
		.fir_text_miss{
			width: 500rpx;
			height: 80rpx;
			padding-left: 20rpx;
			// border-right: 1px solid #031C38;
			color: #031C38;
			&>view:nth-child(1){
				font-size: 35rpx;
			}
			&>view:nth-child(2){
				font-size: 25rpx;
			}
		}
		
	}
	
</style>
