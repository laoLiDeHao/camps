<template>
	<view class="login_mainbox">
		<view class="login_text">
			Camps,Welcome!
		</view>
		<view class="login_btm">
			<button @click="adminIn">授权使用</button>
		</view>
		<view class="login_logo">
			<image src="https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Camps/login/camp_logo.png" mode=""></image>
		</view>
		<view class="login_text2">
			May the flame guide U
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			adminIn(){
				// uni.getLocation({
				// 	type: 'wgs84',
				// 	success: function (res) {
				// 		console.log('当前位置的经度：' + res.longitude);
				// 		console.log('当前位置的纬度：' + res.latitude);
				// 	}
				// });
				uni.switchTab({
					url:"../Mainpage/Mainpage"
				})
			},
		}
	}
</script>

<style lang="less" scoped>

	.login_mainbox{
		width: 750rpx;
		height: 100vh;
		background: red;
		background-image: url(https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Camps/login/42a5bcb4f8128b7c4f6c301deee9d373b0cbe70d155781-6rQPYW.jpg);
		background-size: 750rpx 100vh;
		background-repeat: no-repeat;
		border-top: 1px black solid;
	}
	.login_text{
		margin-top: 300rpx;
		margin-bottom: 170rpx;
		width: 750rpx;
		height: 80rpx;
		font-size: 60rpx;
		text-align: center;
		// background: white;
		color: white;
	}
	.login_text2{
		width: 750rpx;
		height: 80rpx;
		font-size: 60rpx;
		text-align: center;
		background: white;
		position: absolute;
		bottom: 0;
	}
	.login_btm{
		width: 200rpx;
		margin:auto;
	}
	.login_logo{
		position: relative;
		top: 290rpx;
		image{
			width: 200rpx;
			height: 200rpx;
		}
	}
</style>
