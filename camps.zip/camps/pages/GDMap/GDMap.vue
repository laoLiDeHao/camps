<template>
	<view class="map_container">
	  <map class="map" id="map" 
	  :longitude="longitude" :latitude="latitude" 
	  scale="14" show-location="true" 
	  :markers="markers" bindmarkertap="makertap"
	  :polyline="polyline"
	  v-if="latitude"
	  ></map>
	</view>
	<input type="text" placeholder="起点"  v-model="start">
	<input type="text" placeholder="终点" @input="bindinput" v-model="target">
	<view class="tips" v-for="item in tips" :key="item.id" @click="selectThis(item)" >
		{{item.name}}
	</view>
	<button @click="bindWalk">步行</button>
	<button>驾车</button>
	<button>公交</button>
	
</template>

<script>
	import  amap from '../../libs/amap-wx.130.js'
	
	export default {
		name:"GDMap",
		
		data() {
			return {
				// 网页输入输出
				target:'xx',//输入框  mudidi
				start:'ss',//输入框 初始
				// 高德地图
				key:'35e208c3050694260e292c0bb9eed6f1',
				amap:null,//存放高德地图实例
				src: '',//不知道
				tips:[],//存放模糊搜索推荐
				currentTarget :{},
				//原生 地图参数
				longitude:'124',
				latitude:'25',
				markers:[
				],
				points:[],
				polyline:[],
				textData: {}
			};
			
		},
		methods:{
			bindinput(e){
				console.log(e.target.value)
				let keywords = e.target.value
				// console.log(this.amap)
				this.amap.getInputtips({
					keywords:keywords,
					location :'',
					success:(res)=>{
						if(res.tips[0]){
							this.tips = res.tips
							console.log(this.tips)
						}
					}
				})
			},
			selectThis(item){
				console.log(item)
				// 记录location
				let targetTemp = item.location.split(',')
				this.target = item.name
				this.tips=[]
				// this.points = [...this.points,{
				// 	longitude: targetTemp[0],
				// 	latitude: targetTemp[1],
				// }]
				this.points[1] ={
					longitude: targetTemp[0],
					latitude: targetTemp[1],
				}
				
				this.markers =[...this.markers,{
					id:2,
					longitude: targetTemp[0],
					latitude: targetTemp[1],
					height:30,
					width:30,
					iconPath:'../../static/logo.png'
				}]
			},
			bindWalk(){
				// console.log(">>",this.polyline)
				this.polyline=[]
				this.amap.getWalkingRoute(this.getDataObject());
			},
			getDataObject(color){
				let _this = this;
				let colors = color || '#00AC62';
				// console.log("@",this.points)
				return{
					origin:_this.points[0].longitude+','+_this.points[0].latitude,
					destination:_this.points[1].longitude+','+_this.points[1].latitude,
					success:function(data){
						// console.log(">>",data)
						if(!data.paths){
							console.log('search failed')
							return;
						}
						let steps = data.paths[0].steps
						let points = []
						// console.log(">",steps)
						for(let i = 0 ; i <steps.length;i++){
							let polylines = steps[i].polyline.split(';')
							for(let j = 0 ; j <polylines.length;j++){
								let locations = polylines[j].split(',');
								points.push({
									longitude: locations[0],
									latitude: locations[1],
								})
							}
						}
						// 注意这里
						_this.polyline =[{
							points:points,
							color:colors,
							width:6
						}] 
						// _this.polyline =[..._this.polyline,{
						// 	points:points,
						// 	color:colors,
						// 	width:6
						// }] 
						// console.log("@",_this.polyline)
					}
				}
				
			}
		},
		onLoad() {
			// 初始化高德地图对象
			console.log(amap)
			this.amap = new amap.AMapWX({key:'35e208c3050694260e292c0bb9eed6f1'})
			
		
			
			// 初始化地图
			let _this = this
			
			uni.getLocation({
				type: 'wgs84',//北斗
				success: function (res) {
					// _this.setData({
					// 	longitude : res.longitude,
					// 	latitude : res.latitude
					// })
				
					_this.markers =[..._this.markers,{
						id:0,
						longitude: res.longitude,
						latitude:res.latitude,
						height:30,
						width:30,
						iconPath:'../../static/logo.png'
					}]
					
					_this.longitude = res.longitude
					_this.latitude = res.latitude
					
					_this.points = [..._this.points,{
						longitude: res.longitude,
						latitude:res.latitude,
					}]
					console.log('当前位置的经度：' + res.longitude);
					console.log('当前位置的纬度：' + res.latitude);
				}  
			});
			
			
			
			// 检测位置
		
		  // var that = this;
		  //   var myAmapFun = new amapFile.AMapWX({key:'35e208c3050694260e292c0bb9eed6f1'});
		  //   myAmapFun.getRegeo({
		  //     success: function(data){
		  //       //成功回调
				// console.log("》》",data)
		  //     },
		  //     fail: function(info){
		  //       //失败回调
		  //       console.log(info)
		  //     }
		  //   })
    			    
		},
	
		onShow(){
			uni.onLocationChange((res)=>{
				console.log(res)
			})
		}
	}
</script>

<style lang="less">
.map_container{
	width: 750rpx;
	height: 700rpx;
  // position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.map{
  width: 100%;
  height: 100%;
}
.tips{
	width: 750rpx;
	height: 60rpx;
	border: 1rpx black solid;
}
</style>
