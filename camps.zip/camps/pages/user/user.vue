<template>
	<unicloud-db v-slot:default="{data, loading, error, options}" collection="users"  where="name=='Allen'">
		
		<view v-if="error">{{error.message}}</view>
		
		
		
		<view v-else>
			<view class="">
				<!-- {{data[1]}} -->
			</view>
			<view class="user_main" >
				<view class="user_topBar">
					<view>
						<view>
							<uni-icons custom-prefix="custom-icon" type="map-pin-ellipse" color="#F9DE00" size="30"></uni-icons>
						</view>
						<view>正在游荡中</view>
					</view>
					
					<view>
						sss
					</view>
				</view>
				<view class="user_background">
					<image :src="data[0].cover" mode=""></image>
				</view>
				
				<view class="user_base">
					<view>
						<view>
							<image :src="data[0].photo" mode=""></image>
						</view>
						<view>Hi,{{data[0].name}}</view>
					</view>
					<view>
						通讯录好友 >
					</view>
				</view>
			
				
				<view class="user_achieve">
					<!-- 燃烧热量 -->
					<view>
						<view>
							<view>Burn calories</view>
							<view>
								<uni-icons custom-prefix="custom-icon" color="#F9DE00" type="fire-filled" size="25"></uni-icons>
							</view>
						</view>
						
						<view v-if="per1=='day'">{{data[0].achive.kcal.day}}Kcal</view>
						<view v-else-if="per1=='week'">{{data[0].achive.kcal.week}}Kcal</view>
						<view v-else>{{data[0].achive.kcal.month}}Kcal</view>
						<view>
							<view>
								<view  :class="[per1=='day'?'tag_act':'tags']" @click="per1='day'">每天</view>
								<view :class="[per1=='week'?'tag_act':'tags']" @click="per1='week'">每周</view>
								<view :class="[per1=='month'?'tag_act':'tags']" @click="per1='month'">每月</view>
							</view>
						</view>
					</view>
					<!-- 里程 -->
					<view>
						
						<view>
							<view>Consumed</view>
							<view>
								<uni-icons custom-prefix="custom-icon" color="#F9DE00" type="medal" size="25"></uni-icons>
							</view>
						</view>
						
						<view v-if="per2=='day'">{{data[0].achive.Consum.day}}Kcal</view>
						<view v-else-if="per2=='week'">{{data[0].achive.Consum.week}}Kcal</view>
						<view v-else>{{data[0].achive.Consum.month}}Kcal</view>
						<view>
							<view>
								<view  :class="[per2=='day'?'tag_act':'tags']" @click="per2='day'">每天</view>
								<view :class="[per2=='week'?'tag_act':'tags']" @click="per2='week'">每周</view>
								<view :class="[per2=='month'?'tag_act':'tags']" @click="per2='month'">每月</view>
							</view>
						</view>
					</view>
					
				</view>
			
				<view class="user_adv">
					
					<view>
						<view>Activities</view>
						<view @click="toAdventure">更多活动></view>
					</view>
					<view>
						<!-- 活动 -->
						<view class="acts" v-for="item in data[0].activities">
							<view>
								<image :src="item.cover" mode=""></image>
								<!-- 放头像 -->
							</view>
							<view>
								<view>{{item.title}}</view>
								<view><text class="gray">发起者：</text>{{item.holder}}</view>
								<view><text class="gray">活动时间：</text>{{item.time}}</view>
								<view><text class="gray">计划人数：</text>{{item.amount}}</view>	
								<view v-if="item.statu===3"><text class="gray">已完成</text></view>	
											
							</view>
						</view>

					</view>
				</view>
			</view>
			
		</view>
		<!-- <view class="user_background">
			<image :src="data[0].cover" mode=""></image>
		</view> -->
	
	</unicloud-db>
</template>

<script>
	export default {
		data() {
			return {
				per1:'day',
				per2:'month'
			}
		},
		methods: {
			toAdventure(){
				uni.switchTab({
							url: "/pages/adventure/adventure",
							animationType: 'pop-in',
							animationDuration: 300
						})
			}
		}
	}
</script>

<style lang="less" scoped>
	.user_main{
		width: 750rpx;
		// height: 1440rpx;
		background: rgba(51 , 51, 51, 0.98);
	}
	.user_topBar{
		width: 700rpx;
		padding: 0 25rpx 0 25rpx;
		height: 70rpx;
		margin: auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
		color: #F9DE00;
		border-bottom: 2px solid #F9DE00;
		&>view:nth-child(1){
			display: flex;
			justify-content: center;
			align-items: center;
		}
	}
	
	.user_base{
		width: 750rpx;
		height: 300rpx;
		// border: 1px red solid;
		// background: wheat;
		display: flex;
		justify-content: space-around;
		align-items: flex-end;
		margin-bottom: 70rpx;
		&>view:nth-child(1){
			width: 350rpx;
			height: 140rpx;
			// border: 1px solid red;
			display: flex;
			justify-content: center;
			align-items: center;
			position: relative;
			top: 70rpx;
			&>view:nth-child(1){
				width: 120rpx;
				height: 120rpx;
				margin-right: 20rpx;
				background: aquamarine;
				border-radius: 60rpx;
				overflow: hidden;
				image{
					width: 130rpx;
					height: 130rpx;
				}
			}
			&>view:nth-child(2){
				width: 200rpx;
				height: 150rpx;
				color: white;
				line-height: 150rpx;
				font-weight: 700;
				font-size: 40rpx;
			}
		}
		&>view:nth-child(2){
			width: 200rpx;
			height: 60rpx;
			line-height: 60rpx;
			text-align: center;
			background-color: #F9DE00;
			color: black;
			border-radius: 5rpx;
			// border: 1px solid red;
			position: relative;
			top: 30rpx;
		}
	}
	
	.user_achieve{
		width: 750rpx;
		padding: 20rpx 0 10rpx 0;
		display: flex;
		justify-content: space-around;
		align-items: center;
		// background: pink;
		&>view:nth-child(1){
			border-right: 2px #F9DE00 solid;
		}
		&>view{
			width: 350rpx;
			height: 380rpx;
			// background: pink;
			// border: 1px crimson solid;
			// 顶部两个小物件
			&>view:nth-child(1){
				width: 350rpx;
				height: 50rpx;
				display: flex;
				justify-content: space-around;
				&>view:nth-child(1){
					width: 200rpx;
					height: 50rpx;
					text-align: center;
					line-height: 50rpx;
					font-size: 30rpx;
					border-radius: 10rpx;
					background: #F9DE00;
				}
				&>view:nth-child(2){
				}
			}
		
			// 中部数据文字
			&>view:nth-child(2){
				width: 350rpx;
				height: 200rpx;
				// border: 1px blue solid;
				color: #F9DE00;
				line-height: 200rpx;
				text-align: center;
				font-size: 50rpx;
			}
			// 下方选择器
			&>view:nth-child(3){
				width: 350rpx;
				height: 100rpx;
				// border: 1px blue solid;
				display: flex;
				justify-content: center;
				align-items: center;
				&>view{
					width: 240rpx;
					height: 50rpx;
					color: white;
					display: flex;
					background: black;
					border-radius: 25rpx;
					justify-content: space-around;
					.tags{
						width: 80rpx;
						height: 50rpx;
						background: black;
						border-radius: 25rpx;
						font-size: 30rpx;
						line-height: 50rpx;
						text-align: center;
					}
					.tag_act{
						width: 80rpx;
						height: 50rpx;
						background: #F9DE00;
						color: black;
						border-radius: 25rpx;
						font-size: 30rpx;
						line-height: 50rpx;
						text-align: center;
					}
				}
			}
		}
	}

	.user_adv{
		width: 700rpx;
		padding: 40rpx 0 20rpx 0;
		margin: auto;
		// border: 1px red solid;
		&>view:nth-child(1){
			width: 700rpx;
			height: 50rpx;
			display: flex;
			justify-content: space-between;
			&>view:nth-child(1){
				width: 220rpx;
				height: 50rpx;
				line-height: 50rpx;
				background: #F9DE00;
				text-align: center;
				border-radius: 10rpx;
			}
			&>view:nth-child(2){
				color: white;
				cursor: pointer;
			}
		}
		
		// 放活动的框
		&>view:nth-child(2){
			width: 680rpx;
			padding: 30rpx 10rpx 20rpx 10rpx;
			// 每个活动
			.acts{
				width: 680rpx;
				height: 270rpx;
				margin-bottom: 30rpx;
				background: #666666;
				border-radius: 15rpx;
				display: flex;
				justify-content: space-around;
				align-items: center;
				// 封面
				&>view:nth-child(1){
					width: 230rpx;
					height: 230rpx;
					background: white;
					display: flex;
					justify-content:  center;
					align-items: center;
					image{
						width: 220rpx;
						height: 220rpx;
						display: block;
					}
				}
				// 介绍
				&>view:nth-child(2){
					width: 400rpx;
					height: 230rpx;
					
					// background: greenyellow;
					&>view{
						color: white;
						margin-bottom: 10rpx;
						
					}
					&>view:nth-child(1){
						font-weight: 700;
					}
					
					.gray{
						color: lightgray;
					}
				}
			}
		}
	}
	
	.user_background{
		width: 750rpx;
		height: 200rpx;
		position: absolute;
		top: 75rpx;
		// z-index: -1;
		image{
			width: 750rpx;
			height: 320rpx;
			opacity: 0.6;
		}
	}
</style>
