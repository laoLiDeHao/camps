<template>
	<view class="charts-box">
	    <qiun-data-charts 
	      type="line"
	      :opts="opts"
	      :chartData="chartData"
	    />
	  </view>
</template>

<script>
	export default {
		data() {
			return {
				 chartData: {},//参数配置写这
				 
				  opts: {
				         color: ["#FAC858"],
				         padding: [15,10,0,15],
				         legend: {},
				         xAxis: {
				           disableGrid: true
				         },
				         yAxis: {
							disabled:true,
				           gridType: "dash",
				           dashLength: 2
				         },
				         extra: {
				           line: {
				             type: "curve",
				             width: 2
				           }
				         }
				       }
				
			}
		},
		 onReady() {
		    this.getServerData();
		  },
		methods: {
			 getServerData() {
			      //模拟从服务器获取数据时的延时
			      setTimeout(() => {
			        //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
			        let res = {
			            categories: ["12","13","14","15","16","17","18"],
			            series: [
			              {
			                name: "近日趋势：KM",
			                data: [6,8,9,8,9,11,10]
			              }
			            ]
			          };
			        this.chartData = JSON.parse(JSON.stringify(res));
			      }, 500);
			    },
		}
	}
</script>

<style scoped>
  /* 请根据实际需求修改父元素尺寸，组件自动识别宽高 */
  .charts-box {
    width: 700rpx;
    height: 380rpx;
  }
</style>