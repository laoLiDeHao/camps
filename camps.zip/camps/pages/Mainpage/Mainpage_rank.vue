<template>
	<view class="Main_rank_mainbox">
		<view class="switchRanks">
			<view :class="[per=='day'?'Main_rank_ranks_act':'Main_rank_ranks']" @click="per = 'day'">每天</view>
			<view :class="[per=='week'?'Main_rank_ranks_act':'Main_rank_ranks']" @click="per = 'week'">每周</view>
			<view :class="[per=='month'?'Main_rank_ranks_act':'Main_rank_ranks']" @click="per = 'month'">每月</view>
		</view>
		<view class="Main_rank_list">
			<unicloud-db v-slot:default="{data, loading, error, options}" collection="ranks">
				<view v-if="error">{{error.message}}</view>
				<view v-else>
				<template v-for="item in data" :key="_id">
					<template v-if="item.per == per">
						<view class="Main_rank_item" v-for="lists in item.list" :key="index" >
							<view>{{lists.rank}}</view>&nbsp;&nbsp;&nbsp;&nbsp;
							<text>{{lists.name}}</text>
							<text>{{lists.mileage}}km</text>
							<text>❤</text>
						</view>
					</template>
				</template>>
				</view>
			</unicloud-db>
			<!-- <view class="Main_rank_item">
				<view></view>
			</view>
			<view class="Main_rank_item"><view></view></view>
			<view class="Main_rank_item"><view></view></view> -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 排行榜排行方式
				per:'day'
			}
		},
		methods: {
			getRankList(){
				uniCloud
			}
		}
	}
	
</script>

<style scoped lang="less">
	.Main_rank_mainbox{
		width: 750rpx;
		height: 350rpx;
		// background: white;
		margin-top: 20rpx;
	}
	.switchRanks{
		width: 700rpx;
		height: 50rpx;
		margin: auto;
		background: black;
		border-radius: 25rpx;
		display: flex;
		justify-content: space-around;
	}
	.Main_rank_ranks{
		width: 200rpx;
		height: 50rpx;
		border-radius: 25rpx;
		color: white;
		text-align: center;
	}
	.Main_rank_ranks_act{
		width: 200rpx;
		height: 50rpx;
		border-radius: 25rpx;
		background: #F9DE00;
		text-align: center;
		// transition: all 0.2s linear;
	}
	.Main_rank_list{
		
	}
	.Main_rank_item{
		width: 700rpx;
		height: 100rpx;
		margin: 20rpx auto;
		line-height: 100rpx;
		text-align: center;
		font-weight: 700;
		background: white;
		border-radius: 50rpx;
		display: flex;
		align-items: center;
		justify-content: left;
		overflow: hidden;
		view{
			display: block;
			width: 98rpx;
			height: 98rpx;
			border-radius: 48rpx;
			
		}
		text{
			display: block;
			width: 150rpx;
			margin-left: 50rpx;
		}
		&>text:nth-child(4){
			color: red;
		}
	}
	.Main_rank_item:nth-child(1){
		border: 3px red solid;
		view{
			border-right: 3px crimson solid;
		}
	}
	.Main_rank_item:nth-child(2){
		border: 3px #F9DE00 solid;
		view{
			border-right: 3px #F9DE00 solid;
		}
	}
	.Main_rank_item:nth-child(3){
		border: 3px black solid;
		view{
			border-right: 3px black solid;
		}
	}
</style>