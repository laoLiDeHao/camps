<template>
	<view class="Main_mainbox">
		<view class="Main_speed_chart">
			<speed></speed>
		</view>
		<!-- 排行榜 -->
		<view class="Main_ranks">
			<view class="Main_ranks_title">排行榜</view>
			<rank></rank>
			<view class="Main_adBlock">广告位招租，低至0.03元/h</view>
		</view>
		<view class="Main_btns" @click="toRankList">
			查看排行
		</view>
		<view class="Main_btns" @click="toAction">
			开始运动
		</view>
		<view class="Main_btns" @click="toGDMap">
			路径规划	
		</view>
	</view>
</template>

<script>
	import rank from './Mainpage_rank'
	import speed from './Mainpage_speed'
	export default {
		components:{rank,speed},
		data() {
			return {
				
			}
		},
		methods: {
			toRankList(){
				uni.navigateTo({
					url:"../rankTotal/rankTotal"
				})
			},
			toAction(){
				uni.navigateTo({
					url:"../action/action"
				})
			},
			toGDMap(){
				uni.navigateTo({
					url:"../GDMap/GDMap"
				})
			}
		},
		onShow(){
			// let pages = getCurrentPages().length - 1;
			//     console.log('需要销毁的页面：'+pages);
			//     wx.navigateBack({
			//       delta: pages
			//     })
		}
	}
</script>

<style scoped lang="less">
	.Main_mainbox{
		width: 750rpx;
		background: #2C313C;
		padding: 20rpx 0 20rpx 0 ;
		// border: 1px solid red;
	}
	.Main_speed_chart{
		width: 750rpx;
		height: 400rpx;
		// border: 1px solid red;
	}
	.Main_ranks{
		width: 750rpx;
		height:700rpx;
		background: #333333;
	}
	.Main_ranks_title{
		text-align: center;
		color: white;
	}
	.Main_adBlock{
		width: 700rpx;
		height: 150rpx;
		background: white;
		margin: auto;
		position: relative;
		top: 120rpx;
	}
	.Main_btns{
		width: 700rpx;
		height: 100rpx;
		margin: 20rpx auto;
		line-height: 100rpx;
		text-align: center;
		font-weight: 700;
		background: #F9DE00;
		border-radius: 50rpx;
	}

</style>
