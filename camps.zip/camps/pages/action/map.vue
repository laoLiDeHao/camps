<template>
	<!-- :markers="markers" -->
	<view class="action">
		<map name="" 
		id="mapBlock"
		:latitude="latitude"
		:longitude="longitude"
		style="width: 750rpx;
		 height: 1400rpx;"
		show-compass="true"
		show-location="true"
		v-if="ready"
		></map>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				latitude:0,
				longitude:0,
				ready:false,
				markers:[{
					id:0,
					width:50,
					height:50,
					latitude:0,
					longitude:0,
					iconPath:''
				}]
			}
		},
		methods:{
			getUserinfo(){
				let _this = this
				uni.getLocation({
					type: 'wgs84',
					success: function (res) {
						_this.longitude = res.longitude,
						_this.latitude = res.latitude,
						console.log('当前位置的经度：' + res.longitude);
						console.log('当前位置的纬度：' + res.latitude);
					}
				});
				 uni.getUserInfo({
				      provider: 'weixin',
				      success: function (infoRes,rawData,encryptedData) {
				        // console.log('用户：' + infoRes.userInfo.avatarUrl);
				        // console.log('用户：' + infoRes.userInfo.nickName	);
				        // console.log('用户：' + infoRes.rawData);
				        // console.log('用户：' + infoRes.encryptedData);
						_this.markers[0].iconPath = infoRes.userInfo.avatarUrl
						_this.ready = true
						
				      }
				    });
		},
		},
		watch: {
			longitude(newValue) {
					this.markers[0].longitude = newValue
			},
			latitude(newValue) {
				this.markers[0].latitude = newValue
			},
				
		},
		onShow() {
			this.getUserinfo()
		}
		
		
	}
</script>

<style lang="less" scoped>

</style>
