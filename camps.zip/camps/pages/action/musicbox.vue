<template>
	<view class="musicBox_main">
	<!-- 	<audio
		 id="musicBox_palyer"
		 ref="palyer"
		 :src="playing.src" controls="true" :name="playing.name" :aunextthor="playing.author" :poster="playing.photo"
		@timeupdate="timeupdate"
		></audio>
		<button @click="checkPlayer">点击检查播放器</button> -->
		<!-- <button @click="pause">stop/play</button>
		<button @click="next">切歌</button> -->
		<!-- 播放器样式 -->
		<view class="music_Box">
			<view class="music_left">
				<!-- 用于放歌曲封面 -->
				<image :src="index.photo" mode=""></image>
			</view>
			<view class="music_right">
				<view >
					<view >
						{{index.name}}
					</view>
					<view>
						{{index.author}}
					</view>
					<view class="progress-box">
						<progress :percent="percent" activeColor="#10AEFF" stroke-width="3" />
					</view>
				</view>
				<view >
					<view>
						<image src="/static/musicPlayer/heart-fill.png" mode=""></image>
					</view>
					<view @click="pre()">
						<image src="/static/musicPlayer/per.png" mode=""></image>
					</view>
					<view v-if="play" @click="pause">
						<image src="/static/musicPlayer/pause.png" mode=""></image>
					</view>
					<view v-else @click="pause">
						<image src="/static/musicPlayer/play3.png" mode=""></image>
					</view>
					<view @click="next()">
						<image src="/static/musicPlayer/next.png" mode=""></image>
					</view>
					<view>
						<image src="/static/musicPlayer/addto.png" mode=""></image>
					</view>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default{
		data(){
			return{
				musi:null,
				play:false,
				playing:0,
				percent:0,
				index:{
						no:0,
						name:"snake eye",
						src:"https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Feint,CoMa - Snake Eyes.mp3",
						author:'Feint,CoMa',
						photo:"https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/snakeEyes.png"
					},
				src:'https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/snakeEyes.png',
				playList:[
					{
						no:0,
						name:"snake eye",
						src:"https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Feint,CoMa - Snake Eyes.mp3",
						author:'Feint,CoMa',
						photo:"https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/snakeEyes.png"
					},
					{
						no:1,
						name:"晴天",
						src:"https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/晴天-周杰伦.mp3",
						author:'周杰伦',
						photo:"https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/snakeEyes.png"
					},
				]
			}
		},
		methods:{
			// timeupdate(res){
			// 	console.log(res)
			// },
			// checkPlayer(){
			// 	console.log(this.$refs)
			// }
			pre(){
				this.play=true
				this.playing--
				if(this.playing<0){
					this.playing=this.playList.length-1
				}
				console.log(this.playing)
				// this.music.stop()
				this.index = this.playList[this.playing]
				this.music.src=this.index.src
				
				console.log(this.music.src)
				// this.music.play()
			},
			pause(){
				if(this.music.paused){
					this.music.play()
					this.play=true
				}else{
					this.music.pause()
					this.play=false
				}
				
			},
			next(){
				this.play=true
				this.playing++
				if(this.playing>this.playList.length-1){
					this.playing=0
				}
				this.index = this.playList[this.playing]
				console.log(this.playing)
				// this.music.stop()
				this.music.src=this.index.src
				
				console.log(this.music.src)
				// this.music.play()
			}
		},
		onLoad() {
				let _this = this
				this.music = uni.createInnerAudioContext(); //创建播放器对象
				this.music.src = this.playList[0].src; // static文件夹下的音频
				this.music.autoplay=true
				this.music.pause()
				// this.music.play(); //执行播放
				this.music.onTimeUpdate(()=>{
					
					_this.percent = parseFloat(_this.music.currentTime/_this.music.duration *100)
					console.log(_this.percent)
				})
				this.music.onEnded(() => {
					// //播放结束
					// music = null;
				});
				
		},
		onHide(){
			console.log("wochangqilaile ")
		},
		computed:{
			// index(){//现在播放的曲目
			// 	let temp = this.playList[this.playing]
			// 	this.music.src = temp.src
			// 	this.music.play()
			// 	return temp
			// }
		},
		watch:{
			playing(newval){
				
				console.log("index:",this.index)
			}
		}
		
	
	}
</script>

<style lang="less" scoped>
	.musicBox_main{
		width: 750rpx;
		height: 380rpx;
		// background: red;
	}
	.music_Box{
		width: 700rpx;
		height: 300rpx;
		margin: auto;
		background: rgba(255, 255, 255, 0.9);
		border: gray 1px solid;
		border-radius: 30rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		.music_left{
			width: 200rpx;
			height: 200rpx;
			background: black;
			display: flex;
			justify-content: center;
			align-items: center;
			image{
				display: block;
				width: 190rpx;
				height: 190rpx;
			}
			
		}
		.music_right{
			width: 450rpx;
			height: 200rpx;
			// border: black 1px solid;
			
			&>view:nth-child(1){
				width: 420rpx;
				height: 110rpx;
				margin: auto;
				&>view:nth-child(1){
					font-size: 35rpx;
				}
				&>view:nth-child(2){
					font-size: 25rpx;
				}
				.progress-box{
					padding-top: 15rpx;
					height: 15rpx;
				}
			}
			&>view:nth-child(2){
				border-top: 2px solid black;
				width: 420rpx;
				height: 90rpx;
				margin: auto;
				display: flex;
				justify-content: space-around;
				align-items: center;
				&>view{
					width: 75rpx;
					height: 75rpx;
					// border: black 1px solid;
					display: flex;
					justify-content: center;
					align-items: center;
					image{
						width: 65rpx;
						height: 65rpx;
					}
				}
			}
		}
	}
	
</style>