<template>
	<view class="action_map">
		<maps></maps>
	</view>
	<view class="action_Player" :class="[play ? 'play_act':'play_none']">
		<view class="actionP_toggle" @click="play=!play">
			<uni-icons v-if="!play" color="#F9DE00" type="top" size="30"></uni-icons>
			<uni-icons v-else color="#F9DE00" type="bottom" size="30"></uni-icons>
		</view>
		<view class="action_run">
			<view class="action_sun">
				{{sum.toFixed(2)}} 公里
			</view>
			<view class="action_start" @click="startrun">
				<image src="https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Camps/go.png" mode=""></image>
			</view>
			<view class="action_start" @click="stoprun">
				<image src="https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Camps/stop.png" mode=""></image>
			</view>
			<view class="action_start" @click="quitrun">
				<image src="https://7463-tcb-rwz8hgko3aa5d3-0dwkv2bc58252-1312627499.tcb.qcloud.la/Camps/quit.png" mode=""></image>
			</view>
		</view>
		<view class="action_count">
			<view >
				<view>运动时间</view>
				<view>{{timeReal.h}}：{{timeReal.m}}：{{timeReal.s}}</view>
			</view>
			<view >
				<view>速度</view>
				<view>{{speed.toFixed(2)}} km/s</view>
			</view>
			<view >
				<view>消耗热量</view>
				<view>{{cost.toFixed(2)}} Kcal</view>
			</view>
		</view>
		<musicBox></musicBox>
	</view>
	
</template>

<script>
	import maps from './map'
	import musicBox from './musicbox'
 	export default {
		components:{maps,musicBox},
		data() {
			return {
				nickName:"other4",//用户姓名
				weight:66,//体重
				play:true,
				run:false,//是否在跑
				speed:0,//km/h
				sum:0,//总路程
				cost:0,//消耗热量
				times:0,//总时间
				timeReal:{h:0,m:0,s:0},
				timer:null,//定时器
				speeder:null,//随即速度
				res:{}//缓存本次运动量
			};
		},
		methods:{
			startrun(){//开始
				this.run = true
			},
			stoprun(){//暂停
				this.run = false
				this.speed =0
			},
			quitrun(){//结束
			
				this.run = false
				this.speed =0
				let _this=this
				this.res =JSON.stringify({
					sum:_this.sum,//总路程
					time:_this.times,
					cost:_this.cost,
				}) 
				
				uni.showModal({
					title: '本次活动完成，是否分享本次数据',
					content: `本次总行程${_this.sum.toFixed(2)}公里，大约消耗${_this.cost.toFixed(2)}Kcal热量`,
					success: function (res) {
						if (res.confirm) {
							console.log('用户点击确定');
							_this.submitRes()
						} else if (res.cancel) {
							console.log('用户点击取消');
							_this.sum=0
							_this.times =0
							_this.cost =0
							uni.showToast({
								title: '已删除数据',
								duration: 2000
							});
						}
					}
				});
			},
		
			async submitRes(){
				let _this=this
				console.log(this.sum)
				console.log(this.time)
				console.log(this.cost)
				const db = uniCloud.database();
				db.collection('RunRecord')
				.add({
					'name':_this.nickName,
					"sum":_this.sum,
					"time":_this.times,
					"cost":_this.cost
				})
				.then((res)=>{
					console.log(res)
					_this.sum=0
					_this.times =0
					_this.cost =0
					uni.showToast({
						title: '上传成功',
						duration: 2000
					});
				}).catch((err)=>{
				    console.log(err.code); // 打印错误码
						console.log(err.message); // 打印错误内容
				  })
				
				
			}
		},
		watch:{
			run(newval){
				if(newval===true){
					this.timer = setInterval( () => {
					    this.times ++	
						console.log(this.times)
						console.log(this.timeReal)
					}, 1000)
					this.speeder = setInterval( () => {
					    this.speed =Math.floor(Math.random() * 5)+12;	
						this.sum +=(this.speed/3600);//距离增量
						this.cost +=this.sum*this.weight*(this.speed/8)/1000;//消耗增量
						this.timeReal.h = parseInt(this.times/60/60)
						this.timeReal.m = parseInt(this.times/60%60)
						this.timeReal.s = this.times%60
					}, 1000)
				}else{
					clearTimeout(this.timer);  
					clearTimeout(this.speeder);  
					this.timer = null;  
					this.speeder = null;  
				}
			}
		},
		computed:{
			// 总路程
			// integralMeil(){
			// 	let res = 
			// 	return( this.times*18/3600).toFixed(2);
			// },
			// cost(){
			// 	return (this.weight*this.sum*(this.speed/8)/1000).toFixed(3);
			// }
			aveSpeed(){
				return( this.sum/this.times/3600).toFixed(2)
			}
		},
		onShow(){
			uni.getUserInfo({
			     provider: 'weixin',
			     success: function (infoRes,rawData,encryptedData) {
			       // console.log('用户：' + infoRes.userInfo.avatarUrl);
			       console.log('用户：' + infoRes.userInfo.nickName	);
			       // console.log('用户：' + infoRes.rawData);
			       // console.log('用户：' + infoRes.encryptedData);
			     }
			   });
		}
	}
</script>

<style lang="less" scoped>
	.action_map{
		width: 750rpx;
		height:1340rpx;
		background: #282C35;
	}
	.action_Player{
		width: 748rpx;
		height: 800rpx;
		background: #21252B;
		border: 1px solid black;
		position: fixed;
		bottom: 0rpx;
		transition: 0.2s linear all;
	}
	.play_none{
		bottom: -750rpx;
		transition: all 0.2s linear;
	}
	.paly_act{
	}
	.actionP_toggle{
		width: 750rpx;
		height: 70rpx;
		text-align: center;
	}
	// 影藏框里面的移动部分
	.action_run{
		width: 700rpx;
		height: 100rpx;
		margin: auto;
		// border: 1px red solid;
		display: flex;
		justify-content: space-between;
		.action_sun{
			width: 150rpx;
			height: 50rpx;
			line-height: 50rpx;
			color: white;
			font-size: 28rpx;
			font-weight: 700;
		}
		.action_start{
			display: flex;
			justify-content: center;
			align-items: center;
			image{
				width: 100rpx;
				height: 100rpx;
			}
		}
		
	}
	.action_count{
		width: 700rpx;
		height: 200rpx;
		margin: auto;
		// border: 1px red solid;
		display: flex;
		justify-content: space-around;
		align-items: center;
		&>view{
			width: 220rpx;
			height: 200rpx;
			// border: 1px solid red;
			&>view{
				color: white;
				width: 200rpx;
				height: 90rpx;
				
			}
		}
	}

</style>
