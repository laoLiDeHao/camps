// 开发文档: https://uniapp.dcloud.net.cn/uniCloud/cloud-obj
module.exports = {
	say(text){
		console.log(text)
		return {
			errCode:0,
			data:'hello,IM uniCloud'
		}
	}
}
